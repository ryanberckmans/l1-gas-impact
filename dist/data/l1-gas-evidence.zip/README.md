Current snapshot 2026-03-28 through 2026-09-27 UTC.
Read methodology.md and query-manifest.json for current totals and limits.
The baseline-release-6/ directory contains immutable dated evidence, not current derived totals.
Full raw page corpora are preserved separately.

Bulk receipt CSVs are preserved in a separate archive, outside this ZIP and the app repository. See receipt-index.json for checksums and receipt-validation.json for reconciliation.
