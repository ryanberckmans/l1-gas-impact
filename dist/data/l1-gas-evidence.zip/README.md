Current snapshot: 2026-05-09 through 2026-11-08 UTC.
Read methodology.md and query-manifest.json first. historical-baseline/ contains dated preceding-release evidence.

Bulk receipt CSVs are preserved in a separate archive, outside this ZIP and the app repository. See receipt-index.json for checksums and receipt-validation.json for reconciliation.
