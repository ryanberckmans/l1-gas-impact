# L1 Gas Impact: measurement and coverage

Snapshot: **2026-03-28 through 2026-09-27 UTC**, 184 complete days, Ethereum mainnet (chain 1). Snapshot ID: `42a23fd7f5a8a791`.

## Metric

Actual transaction receipt `gasUsed`, including intrinsic gas and the L1 execution portion of blob-carrying transactions. Blob gas, gas limits, gas prices, fees and execution on other chains are excluded. Failed product transactions consume gas and are included when their attribution can be established. The plain ETH-transfer benchmark requires success, positive ETH value, empty input and exactly 21,000 gas.

## Attribution and limitations

The product figures are **verified lower bounds for selected populations**, not exhaustive footprints or a ranking of all Ethereum activity. Count a full parent receipt only when the whole operation is exclusively attributable to the selected product. Do not allocate shared bridge settlement, an arbitrary callback or a mixed router transaction by association alone. Product populations are disjoint; the contextual ETH-transfer benchmark must not be summed with product rows.

Uniswap on L1 covers selected Ethereum routers, liquidity entrypoints and approvals. It excludes Uniswap execution on rollups and unresolved pool or aggregator routes. The latest Universal Router is decoded recursively: bridge commands, unknown commands and utility-only executions are excluded.

Lighter means its primary instance. It includes direct users, settlement, proofs, execution, exclusive helpers and administration linked to the primary deployment. It excludes Lighter on Robinhood. Included receipts cover **11,818 of 90,480** observed deposit parent transactions and **33,150 of 34,382** withdrawal-claim parents in this snapshot. These are transaction coverage counts, not gas coverage percentages; unresolved deposit wrappers are a material gap.

Rollups cover dedicated L1 contracts, reviewed operator-to-inbox traffic, selected approvals and decoded bridge activity. Incoming CCTP messages require successful authentication, the expected source domain and Ethereum token-messenger recipient. Native ETH withdrawal finalizations with unverified callbacks remain excluded. Newly discovered contracts are queried over the full snapshot; discovery alone never implies nonzero activity.

## Verification

Validated March 28–September 14 observations are retained from the previous snapshot. September 15–27 observations are newly acquired. All required queries completed; source population and input checksums gate the build, so a missing source cannot silently become zero.

The refresh reconciles **128 contract query populations by daily count and gas across Routescan and Blockchair**. It resolves **140 conflicting indexed transaction hashes against canonical Ethereum receipts and blocks**. Supplemental approvals and chain-specific bridge queries are fully paginated and ABI-decoded. Seventeen current samples independently check receipt gas, block and recipient for the larger aggregate-only populations and supplemental protocol variants. Sampling is not a full independent recount of Ethereum. Historical index repairs retain their original dated evidence, including the April 16 duplicate-index correction; they are never reapplied to unaffected new responses.

Daily CSV, JSON, receipt downloads and query metadata are generated from the same accepted observations. Receipt exports for Lighter, Base, Arbitrum One and Robinhood cover core contract cohorts; their separate supplemental query cohorts are in the structured dataset. The four other rollup receipt exports cover all of their measured cohorts. Zero means no observed activity inside a completed queried population. Unresolved or undiscovered activity is excluded, not treated as zero.

## Reading the charts

Comparison bars show the selected interval's mean gas per day on a common linear scale beginning at zero. History bars show actual daily gas, and the line shows a trailing seven-day mean only where seven observations exist. The change metric always compares the latest 30 days with the preceding 30. ETH-transfer equivalents divide gas by 21,000; they compare gas demand, not transaction usefulness. Displayed rounded values are accompanied by exact tables and downloads.

The evidence ZIP contains current source responses and checks, plus a clearly separated historical baseline. Historical files describe their own observation window; they are provenance for the reused overlap, not current totals. Full raw research archives are retained separately. This is a fixed snapshot, not a live feed.
