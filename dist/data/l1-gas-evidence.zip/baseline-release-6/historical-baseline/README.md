# L1 Gas Impact — evidence snapshot

Ethereum mainnet, March 15–September 14, 2026 inclusive (UTC).
Actual receipt gasUsed; no blob gas, fees, gas prices or L2 execution.

The comparison covers nine selected products and a contextual ETH-transfer benchmark. Product measurements are exclusive lower bounds with unequal coverage. Read METHODOLOGY.md and query-manifest.json. Do not sum the ETH benchmark with the products.

Original provider aggregate responses, chain identity snapshots, receipt samples and reconciliation records are preserved. The expanded/ directory documents World Chain, Unichain, OP Mainnet and Ink. All their included core, approval and Across/CCTP transactions are in the separate receipt CSV downloads. The original four rollup receipt downloads cover their core populations; supplemental aggregates are identified separately.

Bulky original transaction-page corpora are preserved in separate research archives. A manifest reference does not mean every raw page is bundled here. Original responses may contain the documented index duplicates; use the corrected published dataset, not naive raw sums. CONTENTS.json hashes the bundled bytes. Historical provider records retain their original factual scope. Application source is not included.
