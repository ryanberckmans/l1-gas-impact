Current snapshot 2026-03-28 through 2026-09-27 UTC.
Current totals are in dataset.json and query-manifest.json.
The historical-baseline/ directory is immutable, dated provenance only.
No application source or private working notes are included.
